// Cargamos los modelos para usarlos posteriormente
const Patient = require('../models/patient');

exports.list = async function() {
    console.log("entra en el método list")
    const patients = await Patient.find();
    console.log("patients: ", patients);
    return patients;
}

exports.read = async function(patientId) {
    console.log("entra en el método read")
    var patient = await Patient.findOne({_id: patientId});
    console.log("patient: ", patient);
    return patient;
}

exports.create = async function(body) {
    console.log("BODY: ", body);
    var patient = new Patient(body);
    await patient.save();
    return patient;
}

exports.update= async function(patientId, body) {
    console.log("BODY: ", body);
    console.log("patientId: ", patientId);
    var patient = await Patient.findOne({_id: patientId});
    if (!patient) {
        console.log("Paciente no encontrado con ID: ", patientId);
        return null;
    }   
    Object.assign(patient, body); 
    await patient.save();
    return patient;
}

exports.delete = async function(patientId) {
    console.log("entra en el método delete")
    var patient = await Patient.findOne({_id: patientId});
    await patient.remove();
    console.log("paciente: ", patient, " ha sido eliminado");
    return patient;
}

exports.filterPatientsByCity = async function (city) {
    console.log("buscando pacientes en la ciudad: ", city);
    var patients = await Patient.find({city: city});
    console.log("pacientes encontrados: ", patients);
    return patients;
}

exports.filterPatientsByDiagnosis = async function (diagnosis) {
    console.log("buscando pacientes con diagnóstico: ", diagnosis);
    var patients = await Patient.find({"medicalHistory.diagnosis": diagnosis});
    console.log("pacientes encontrados: ", patients);
    return patients;
}

exports.filterPatientsBySpeacialistAndDate = async function (specialist, sDate,fDate) {
    console.log("buscando pacientes con especialista: ", specialist, " y fecha entre: ", sDate, " y ", fDate);
    var patients = await Patient.find({medicalHistory: { $elemMatch: { specialist: specialist, date: { $gte: sDate, $lte: fDate } } } });
    console.log("pacientes encontrados: ", patients);
    return patients;
}

exports.addPatientHistory = async function (patientId, medicalRecord) {
    console.log("añadiendo historial médico al paciente con ID: ", patientId);
    var patient = await Patient.findOne({_id: patientId});
    if (!patient) {
        console.log("Paciente no encontrado con ID: ", patientId);
        return null;
    }   
    patient.medicalHistory.push(medicalRecord);
    await patient.save();
    return patient;
}